$(document).ready(function() {

    renderSize();

    function renderSize() {

        var win = $(window);

        if (win.width() <= 360) {
            // Hide first and second chile of LI's
            var about = $('#menu li:nth-child(1) ul');
            var buss = $('#menu li:nth-child(2) ul');
            about.hide();
            buss.hide();

            // About Toggle
            $('#menu li:nth-child(1) .navlink').click(function() {
                if (about.is(':visible')) {
                    $('#show-menu').click();
                    about.slideUp('slow');
                } else {
                    // not visible, show back the child of first LI
                    $('#show-menu').click();
                    about.slideDown('slow');
                }
                buss.hide();
                return false;
            });

            // Business Toggle
            $('#menu li:nth-child(2) .navlink').click(function() {
                console.log(this);
                if (buss.is(':visible')) {
                    $('#show-menu').click();
                    buss.slideUp('slow');
                } else {
                    // not visible, show back the child of first LI
                    $('#show-menu').click();
                    buss.slideDown('slow');
                }
                about.hide();
                return false;
            });

            return false;

        }

    }

});