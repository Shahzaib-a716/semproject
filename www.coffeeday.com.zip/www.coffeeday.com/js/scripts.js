jQuery(window).load(function() {

    "use strict";

    // Remove loader

    jQuery('#progress-bar').width('100%');
    jQuery('#loader').hide();

});

jQuery(document).ready(function() {

    "use strict";
    /*	if (navigator.userAgent.match(/MSIE 8/) == null) {
    		jQuery(".main").onepage_scroll({
    			sectionContainer: "div.pagesection",
    			responsiveFallback: 600,
    			loop: false
    		});
    		
    		jQuery('a.navlink').click(function() {
    		   jQuery(".main").moveTo(jQuery(this).data('index'));
    		});
    		
    		alert("Not IE 8");
    	}
    	else{
    		alert("IE 8");
    	}*/

    jQuery(".main").onepage_scroll({
        sectionContainer: "div.pagesection",
        responsiveFallback: 600,
        loop: false
    });

    jQuery('a.navlink').click(function() {
        jQuery(".main").moveTo(jQuery(this).data('index'));
    });

    jQuery('#show-menu').click(function() {
        show_hide_menu();
    });

    function show_hide_menu() {

        if (jQuery('ul#menu').css('display') == 'none') {
            jQuery('#show-menu .mnuimg').rotate({
                animateTo: 0
            });
        } else {
            jQuery('#show-menu .mnuimg').rotate({
                animateTo: 90
            });
        }
        jQuery('ul#menu').fadeToggle();

    }

    jQuery('ul#menu a').click(function() {
        if ($(window).width() < 768) {
            show_hide_menu();
        }
    });
    /*	$('.dummy').viewportChecker({
    		callbackFunction: function(elem, action){
    			setTimeout(function(){
    				elem.html((action == "add") ? 'Callback with 500ms timeout: added class' : 'Callback with 500ms timeout: removed class');
    			},500);
    		}
    	});*/

    // Loader bar

    var count = 1;

    jQuery('#navigation').addClass('sticky-nav');

    jQuery('img').load(function() {

        jQuery('#progress-bar').css('width', count * 170);
        count = count + 1;
    });

    //jQuery('#loader').css('padding-top', jQuery(window).height() / 2);

    // Initialize Sliders

    jQuery('#home-slider').flexslider({
        directionNav: false
    });

    // Adjust slide height for smaller screens

    jQuery('#home-slider .slides li').css('height', jQuery(window).height());


    /*jQuery('#ourstory-title').addClass('animated bounceIn');*/

    // Append HTML <img>'s as CSS Background for slides
    // also center the content of the slide

    jQuery('#home-slider .slides li').each(function() {

        var imgSrc = jQuery(this).children('.slider-bg').attr('src');
        jQuery(this).css('background', 'url("' + imgSrc + '")');
        jQuery(this).children('.slider-bg').remove();

        var slideHeight = jQuery(this).height();
        var contentHeight = jQuery(this).children('.slide-content').height();
        var padTop = (slideHeight / 3) - (contentHeight / 2);

        jQuery(this).children('.slide-content').css('padding-top', padTop);

    });

    // Turn dynamic animations for iOS devices (because it doesn't look right)

    var iOS = false,
        p = navigator.platform;

    if (p === 'iPad' || p === 'iPhone' || p === 'iPod') {
        iOS = true;
    }

});